Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/gfx_simpletest.py
    :caption: examples/gfx_simpletest.py
    :linenos:
