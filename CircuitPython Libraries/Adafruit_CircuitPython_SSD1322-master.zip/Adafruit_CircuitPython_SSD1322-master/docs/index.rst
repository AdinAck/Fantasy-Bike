.. include:: ../README.rst

Table of Contents
=================

.. toctree::
    :maxdepth: 4
    :hidden:

    self

.. toctree::
    :caption: Examples

    examples

.. toctree::
    :caption: API Reference
    :maxdepth: 3

    api

.. toctree::
    :caption: Tutorials

.. toctree::
    :caption: Related Products

    3.12" Newhaven Display 256x64 Grayscale Blue OLED <https://www.newhavendisplay.com/nhd31225664ucb2-p-3622.html>

.. toctree::
    :caption: Other Links

    Download <https://github.com/adafruit/Adafruit_CircuitPython_SSD1322/releases/latest>
    CircuitPython Reference Documentation <https://circuitpython.readthedocs.io>
    CircuitPython Support Forum <https://forums.adafruit.com/viewforum.php?f=60>
    Discord Chat <https://adafru.it/discord>
    Adafruit Learning System <https://learn.adafruit.com>
    Adafruit Blog <https://blog.adafruit.com>
    Adafruit Store <https://www.adafruit.com>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
