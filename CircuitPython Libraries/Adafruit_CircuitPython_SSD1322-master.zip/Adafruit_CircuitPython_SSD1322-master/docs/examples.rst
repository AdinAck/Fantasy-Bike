Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ssd1322_simpletest.py
    :caption: examples/ssd1322_simpletest.py
    :linenos:

Gamma test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ssd1322_gamma.py
    :caption: examples/ssd1322_gamma.py
    :linenos:
